function makeColor()
{
    let r = Number(document.getElementById("inputRed").value);
    let g = Number(document.getElementById("inputGre").value);
    let b = Number(document.getElementById("inputBlu").value);

    let bgd = document.getElementById("changeColor");
    let putAnswer = document.getElementById("hexCode");
    
    if (r>=0 && r<256 && g>=0 && g<256 && b>=0 && b<256)
    {
        let r1 =r<16? "0" + r.toString(16):r.toString(16);
        r1=r1.toUpperCase();
        let g1 =g<16? "0" + g.toString(16):g.toString(16);
        g1=g1.toUpperCase();
        let b1 =b<16? "0" + b.toString(16):b.toString(16);
        b1=b1.toUpperCase();
        
        //bgd.style.backgroundColor = "#"+r1+g1+b1;
        
        bgd.style.backgroundColor = `rgb(${r}, ${g}, ${b})`

        putAnswer.textContent = "0x"+r1+g1+b1;
    }
    else if (r<0 || r>=256 || b<0 || b>=256 || g<0 || g>=256)
    {
        putAnswer.textContent = "Invalid hex code. Follow Instructions.";
        bgd.style.backgroundColor = "white";
    }
    else
    {
        putAnswer.textContent = "Invalid hex code. Follow Instructions.";
        bgd.style.backgroundColor = "white";
        alert("Input(s) not in base 10, null, or not a number.");
    }
}